import React from 'react'
import SearchBar from './components/SearchBar';
const App = () =>{
    return(
        <div>
            <SearchBar />
        </div>
    );
};

export default App;