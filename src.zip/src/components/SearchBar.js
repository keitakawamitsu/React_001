import React from 'react';

const SearcBar= () =>{
    return (
    <div>
        <p>Reactが動いた！！</p>
    </div>
    );
};

export default SearcBar;